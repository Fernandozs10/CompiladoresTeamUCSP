s: str = "café"
