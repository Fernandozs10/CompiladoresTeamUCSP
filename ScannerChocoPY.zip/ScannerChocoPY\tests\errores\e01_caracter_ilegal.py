x: int = 1
y: int = x $ 2
