x: int = 6 / 2
