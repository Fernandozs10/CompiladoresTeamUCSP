s: str = "hola mundo
